import hashlib
import hmac
import secrets

from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import select

from . import config as cfg
from .database import get_db
from . import models as m

router = APIRouter()
templates = Jinja2Templates(directory="templates")

PBKDF2_ITERATIONS = 260_000


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), PBKDF2_ITERATIONS)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, digest_hex = stored.split("$", 1)
    except ValueError:
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), PBKDF2_ITERATIONS)
    return hmac.compare_digest(candidate.hex(), digest_hex)


@router.get("/login")
def login_page(request: Request, error: str | None = None):
    return templates.TemplateResponse("login.html", {
        "request": request, "error": error, "allow_registration": cfg.ALLOW_REGISTRATION,
    })


@router.post("/login")
def login_submit(request: Request, db: Session = Depends(get_db),
                  username: str = Form(...), password: str = Form(...)):
    username = username.strip()
    user = db.scalar(select(m.User).where(m.User.username == username))
    if not user or not verify_password(password, user.password_hash):
        return RedirectResponse("/login?error=invalid", status_code=303)
    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=303)


@router.get("/register")
def register_page(request: Request, error: str | None = None):
    if not cfg.ALLOW_REGISTRATION:
        return RedirectResponse("/login")
    return templates.TemplateResponse("register.html", {"request": request, "error": error})


@router.post("/register")
def register_submit(request: Request, db: Session = Depends(get_db),
                     username: str = Form(...), password: str = Form(...),
                     confirm_password: str = Form(...)):
    if not cfg.ALLOW_REGISTRATION:
        return RedirectResponse("/login")

    username = username.strip()
    if len(username) < 3:
        return RedirectResponse("/register?error=short_username", status_code=303)
    if len(password) < 8:
        return RedirectResponse("/register?error=short_password", status_code=303)
    if password != confirm_password:
        return RedirectResponse("/register?error=mismatch", status_code=303)

    existing = db.scalar(select(m.User).where(m.User.username == username))
    if existing:
        return RedirectResponse("/register?error=taken", status_code=303)

    user = m.User(username=username, password_hash=hash_password(password))
    db.add(user)
    db.commit()
    db.refresh(user)

    from .seed import seed_defaults_for_user
    seed_defaults_for_user(db, user.id)

    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=303)


@router.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login")


def get_current_user(request: Request, db: Session = Depends(get_db)) -> m.User | None:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    return db.get(m.User, user_id)
