from datetime import date
from collections import defaultdict
from sqlalchemy.orm import Session
from sqlalchemy import select
from . import models as m
from . import calculations as calc


def _all(db, model, user_id):
    return db.scalars(select(model).where(model.user_id == user_id)).all()


def dashboard_kpis(db: Session, user_id: str) -> dict:
    items = _all(db, m.InventoryItem, user_id)
    sales = _all(db, m.Sale, user_id)
    purchases = _all(db, m.Purchase, user_id)
    expenses = _all(db, m.Expense, user_id)

    qty_remaining = {i.id: calc.quantity_remaining(db, i) for i in items}
    on_hand = [i for i in items if qty_remaining[i.id] > 0]

    inventory_units = sum(qty_remaining[i.id] for i in on_hand)
    inventory_at_cost = round(
        sum(calc.total_cost_basis(i) / i.quantity * qty_remaining[i.id] for i in on_hand if i.quantity),
        2,
    )
    current_inventory_value = round(sum(i.current_market_value for i in on_hand), 2)

    lifetime_revenue = round(sum(s.sale_price for s in sales), 2)
    lifetime_profit = round(sum(calc.sale_profit(db, s) for s in sales), 2)
    rois = [r for s in sales if (r := calc.sale_roi(db, s)) is not None]
    average_roi = round(sum(rois) / len(rois), 4) if rois else 0
    holds = [h for s in sales if (h := calc.sale_days_held(db, s)) is not None]
    average_hold_time = round(sum(holds) / len(holds), 1) if holds else 0

    items_in_inventory = sum(
        qty_remaining[i.id] for i in items if i.inventory_status == "In Inventory"
    )
    items_listed = sum(qty_remaining[i.id] for i in items if i.listing_status == "Listed")
    items_not_listed = sum(qty_remaining[i.id] for i in items if i.listing_status != "Listed")
    items_sold = sum(s.quantity_sold for s in sales)

    qb_remaining = (
        sum(1 for p in purchases if p.quickbooks_recorded != "Recorded")
        + sum(1 for s in sales if s.quickbooks_recorded != "Recorded")
        + sum(1 for e in expenses if e.quickbooks_recorded != "Recorded")
    )
    cashback_earned = round(sum(p.cashback for p in purchases), 2)

    aging_91plus = sum(
        qty_remaining[i.id]
        for i in items
        if (calc.days_held_item(db, i) or 0) > 90 and qty_remaining[i.id] > 0
    )

    return dict(
        inventory_units=inventory_units,
        inventory_at_cost=inventory_at_cost,
        current_inventory_value=current_inventory_value,
        lifetime_revenue=lifetime_revenue,
        lifetime_profit=lifetime_profit,
        average_roi=average_roi,
        average_hold_time=average_hold_time,
        items_in_inventory=items_in_inventory,
        items_listed=items_listed,
        items_not_listed=items_not_listed,
        items_sold=items_sold,
        qb_remaining=qb_remaining,
        cashback_earned=cashback_earned,
        aging_91plus=aging_91plus,
    )


def monthly_trend(db: Session, user_id: str, months: int = 12) -> list[dict]:
    sales = _all(db, m.Sale, user_id)
    today = date.today()
    # build the list of the last `months` (year, month) buckets ending this month
    buckets = []
    y, mo = today.year, today.month
    for _ in range(months):
        buckets.append((y, mo))
        mo -= 1
        if mo == 0:
            mo, y = 12, y - 1
    buckets.reverse()

    rev = defaultdict(float)
    prof = defaultdict(float)
    for s in sales:
        key = (s.sale_date.year, s.sale_date.month)
        rev[key] += s.sale_price
        prof[key] += calc.sale_profit(db, s)

    return [
        dict(month=f"{y}-{mo:02d}", revenue=round(rev[(y, mo)], 2), profit=round(prof[(y, mo)], 2))
        for (y, mo) in buckets
    ]


def category_performance(db: Session, user_id: str) -> list[dict]:
    items = _all(db, m.InventoryItem, user_id)
    sales = _all(db, m.Sale, user_id)
    items_by_id = {i.id: i for i in items}
    cats = sorted({i.category for i in items if i.category})

    out = []
    for cat in cats:
        cat_items = [i for i in items if i.category == cat]
        qty_rem = {i.id: calc.quantity_remaining(db, i) for i in cat_items}
        cost_basis = round(
            sum(
                calc.total_cost_basis(i) / i.quantity * qty_rem[i.id]
                for i in cat_items if i.quantity
            ), 2,
        )
        current_value = round(sum(i.current_market_value for i in cat_items if qty_rem[i.id] > 0), 2)
        cat_sales = [s for s in sales if items_by_id.get(s.inventory_id) and items_by_id[s.inventory_id].category == cat]
        revenue = round(sum(s.sale_price for s in cat_sales), 2)
        profit = round(sum(calc.sale_profit(db, s) for s in cat_sales), 2)
        cogs_total = sum(calc.sale_cogs(db, s) for s in cat_sales)
        roi = round(profit / cogs_total, 4) if cogs_total else 0
        units_on_hand = sum(qty_rem.values())
        holds = [calc.days_held_item(db, i) for i in cat_items if qty_rem[i.id] > 0]
        holds = [h for h in holds if h is not None]
        avg_hold = round(sum(holds) / len(holds), 1) if holds else 0
        out.append(dict(
            category=cat, cost_basis=cost_basis, current_value=current_value,
            revenue=revenue, profit=profit, roi=roi, units_on_hand=units_on_hand,
            avg_hold_time=avg_hold,
        ))
    return out


def vendor_performance(db: Session, user_id: str) -> list[dict]:
    vendors = _all(db, m.Vendor, user_id)
    purchases = _all(db, m.Purchase, user_id)
    items = _all(db, m.InventoryItem, user_id)
    sales = _all(db, m.Sale, user_id)
    items_by_id = {i.id: i for i in items}
    purchases_by_vendor = defaultdict(list)
    for p in purchases:
        purchases_by_vendor[p.vendor_id].append(p)

    out = []
    for v in vendors:
        spend = round(sum(p.order_total for p in purchases_by_vendor.get(v.id, [])), 2)
        v_item_ids = {i.id for i in items if i.purchase and i.purchase.vendor_id == v.id}
        v_sales = [s for s in sales if s.inventory_id in v_item_ids]
        revenue = round(sum(s.sale_price for s in v_sales), 2)
        profit = round(sum(calc.sale_profit(db, s) for s in v_sales), 2)
        cogs_total = sum(calc.sale_cogs(db, s) for s in v_sales)
        roi = round(profit / cogs_total, 4) if cogs_total else 0
        avg_profit = round(profit / len(v_sales), 2) if v_sales else 0
        out.append(dict(vendor=v.name, spend=spend, revenue=revenue, profit=profit, roi=roi, avg_profit_per_sale=avg_profit))
    return out


def marketplace_performance(db: Session, user_id: str) -> list[dict]:
    marketplaces = _all(db, m.Marketplace, user_id)
    sales = _all(db, m.Sale, user_id)
    out = []
    for mk in marketplaces:
        mk_sales = [s for s in sales if s.marketplace == mk.name]
        revenue = round(sum(s.sale_price for s in mk_sales), 2)
        profit = round(sum(calc.sale_profit(db, s) for s in mk_sales), 2)
        cogs_total = sum(calc.sale_cogs(db, s) for s in mk_sales)
        roi = round(profit / cogs_total, 4) if cogs_total else 0
        avg_profit = round(profit / len(mk_sales), 2) if mk_sales else 0
        holds = [h for s in mk_sales if (h := calc.sale_days_held(db, s)) is not None]
        avg_hold = round(sum(holds) / len(holds), 1) if holds else 0
        out.append(dict(marketplace=mk.name, revenue=revenue, profit=profit, roi=roi,
                         avg_profit_per_sale=avg_profit, avg_hold_time=avg_hold))
    return out


def inventory_aging(db: Session, user_id: str) -> list[dict]:
    items = _all(db, m.InventoryItem, user_id)
    buckets = [("0-30 Days", 0, 30), ("31-90 Days", 31, 90), ("91-180 Days", 91, 180), ("181+ Days", 181, 999999)]
    out = []
    for label, lo, hi in buckets:
        units, cost, value = 0, 0.0, 0.0
        for i in items:
            qty_rem = calc.quantity_remaining(db, i)
            if qty_rem <= 0:
                continue
            held = calc.days_held_item(db, i) or 0
            if lo <= held <= hi:
                units += qty_rem
                if i.quantity:
                    cost += calc.total_cost_basis(i) / i.quantity * qty_rem
                value += i.current_market_value
        out.append(dict(bucket=label, units=units, cost_basis=round(cost, 2), current_value=round(value, 2)))
    return out
