from datetime import datetime, date
from sqlalchemy import (
    String, Integer, Float, Boolean, Date, DateTime, ForeignKey, Text
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base


class User(Base):
    """One row per account. All other tables are scoped to a user_id,
    so every person's data is isolated from everyone else's."""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Vendor(Base):
    __tablename__ = "vendors"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String)
    vendor_type: Mapped[str] = mapped_column(String, default="")
    website: Mapped[str] = mapped_column(String, default="")
    tax_exempt: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str] = mapped_column(Text, default="")


class Purchase(Base):
    __tablename__ = "purchases"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    display_id: Mapped[str] = mapped_column(String)  # PUR-000001
    vendor_id: Mapped[int] = mapped_column(Integer, ForeignKey("vendors.id"))
    order_number: Mapped[str] = mapped_column(String, default="")
    order_date: Mapped[date] = mapped_column(Date)
    payment_method: Mapped[str] = mapped_column(String, default="")
    funding_source: Mapped[str] = mapped_column(String, default="")
    order_total: Mapped[float] = mapped_column(Float, default=0)
    sales_tax: Mapped[float] = mapped_column(Float, default=0)
    shipping: Mapped[float] = mapped_column(Float, default=0)
    cashback: Mapped[float] = mapped_column(Float, default=0)
    order_status: Mapped[str] = mapped_column(String, default="")
    receipt_available: Mapped[str] = mapped_column(String, default="")
    quickbooks_recorded: Mapped[str] = mapped_column(String, default="Not Recorded")
    notes: Mapped[str] = mapped_column(Text, default="")

    vendor: Mapped["Vendor"] = relationship()


class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    display_id: Mapped[str] = mapped_column(String)  # INV-000001
    purchase_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("purchases.id"), nullable=True)
    category: Mapped[str] = mapped_column(String, default="")
    brand: Mapped[str] = mapped_column(String, default="")
    series_set: Mapped[str] = mapped_column(String, default="")
    product_name: Mapped[str] = mapped_column(String, default="")
    variant: Mapped[str] = mapped_column(String, default="")
    condition: Mapped[str] = mapped_column(String, default="")
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    storage_location: Mapped[str] = mapped_column(String, default="")
    purchase_price: Mapped[float] = mapped_column(Float, default=0)
    allocated_sales_tax: Mapped[float] = mapped_column(Float, default=0)
    allocated_shipping_in: Mapped[float] = mapped_column(Float, default=0)
    allocated_cashback: Mapped[float] = mapped_column(Float, default=0)
    current_market_value: Mapped[float] = mapped_column(Float, default=0)
    listing_status: Mapped[str] = mapped_column(String, default="Not Listed")
    inventory_status: Mapped[str] = mapped_column(String, default="In Inventory")
    quickbooks_recorded: Mapped[str] = mapped_column(String, default="Not Recorded")
    notes: Mapped[str] = mapped_column(Text, default="")

    purchase: Mapped["Purchase"] = relationship()


class Sale(Base):
    __tablename__ = "sales"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    display_id: Mapped[str] = mapped_column(String)  # SAL-000001
    inventory_id: Mapped[int] = mapped_column(Integer, ForeignKey("inventory_items.id"))
    sale_date: Mapped[date] = mapped_column(Date)
    marketplace: Mapped[str] = mapped_column(String, default="")
    buyer: Mapped[str] = mapped_column(String, default="")
    order_number: Mapped[str] = mapped_column(String, default="")
    tracking_number: Mapped[str] = mapped_column(String, default="")
    shipping_provider: Mapped[str] = mapped_column(String, default="")
    payment_method: Mapped[str] = mapped_column(String, default="")
    quantity_sold: Mapped[int] = mapped_column(Integer, default=1)
    sale_price: Mapped[float] = mapped_column(Float, default=0)
    sales_tax_collected: Mapped[float] = mapped_column(Float, default=0)
    shipping_cost: Mapped[float] = mapped_column(Float, default=0)
    quickbooks_recorded: Mapped[str] = mapped_column(String, default="Not Recorded")
    notes: Mapped[str] = mapped_column(Text, default="")

    inventory_item: Mapped["InventoryItem"] = relationship()


class Expense(Base):
    __tablename__ = "expenses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    display_id: Mapped[str] = mapped_column(String)  # EXP-000001
    date: Mapped[date] = mapped_column(Date)
    vendor: Mapped[str] = mapped_column(String, default="")
    expense_category: Mapped[str] = mapped_column(String, default="")
    payment_method: Mapped[str] = mapped_column(String, default="")
    amount: Mapped[float] = mapped_column(Float, default=0)
    receipt_attached: Mapped[str] = mapped_column(String, default="No")
    quickbooks_recorded: Mapped[str] = mapped_column(String, default="Not Recorded")
    notes: Mapped[str] = mapped_column(Text, default="")


class Marketplace(Base):
    """Fee assumptions, equivalent to the Reference Lists marketplace columns."""
    __tablename__ = "marketplaces"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String)
    fee_pct: Mapped[float] = mapped_column(Float, default=0)          # e.g. 0.1325
    processing_pct: Mapped[float] = mapped_column(Float, default=0)   # e.g. 0.029
    processing_fixed: Mapped[float] = mapped_column(Float, default=0) # e.g. 0.30


class Option(Base):
    """Generic per-user dropdown list values (categories, brands, conditions,
    payment methods, storage locations, expense categories, shipping providers,
    vendor types, statuses). Equivalent to the Reference Lists tab columns."""
    __tablename__ = "options"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    list_type: Mapped[str] = mapped_column(String, index=True)
    value: Mapped[str] = mapped_column(String)
