from sqlalchemy.orm import Session
from . import models as m

OPTION_DEFAULTS = {
    "category": [
        "Trading Cards", "Sealed TCG Products", "Sports Cards", "Funko Pops", "Comics",
        "Figures", "LEGO", "Plush", "Video Games", "Electronics", "Board Games",
        "Collectible Accessories", "Memorabilia", "Other Collectibles",
    ],
    "brand": [
        "Pokémon", "Magic: The Gathering", "Disney Lorcana", "One Piece", "Yu-Gi-Oh!",
        "Marvel", "DC", "Star Wars", "Funko", "LEGO", "Nintendo", "PlayStation", "Xbox", "Other",
    ],
    "condition": [
        "New / Sealed", "New / Open Box", "Mint", "Near Mint", "Lightly Played",
        "Moderately Played", "Heavily Played", "Damaged", "Used - Like New",
        "Used - Good", "Used - Fair", "Graded",
    ],
    "vendor_type": [
        "Retailer", "Distributor", "Marketplace", "Local Seller", "Convention / Show",
        "Auction", "Private Collection", "Manufacturer / Direct", "Other",
    ],
    "payment_method": [
        "Credit Card", "Debit Card", "ACH / Bank Transfer", "PayPal", "Cash",
        "Store Credit", "Gift Card", "Other",
    ],
    "storage_location": [
        "Office Shelf", "Storage Bin", "Closet", "Warehouse", "Display Case",
        "Safe", "Offsite Storage", "Other",
    ],
    "expense_category": [
        "Accounting / Bookkeeping", "Advertising", "Bank Fees", "Insurance",
        "Office Supplies", "Packaging Supplies", "Postage / Shipping",
        "Professional Services", "Software", "Subscriptions", "Taxes / Licenses",
        "Travel / Mileage", "Utilities", "Other Business Expense",
    ],
    "shipping_provider": ["USPS", "UPS", "FedEx", "DHL", "Local Pickup", "Marketplace Label", "Other"],
    "inventory_status": ["In Inventory", "Listed", "Sold", "Returned", "Canceled", "Lost"],
    "listing_status": ["Not Listed", "Draft", "Listed", "Sold"],
    "quickbooks_status": ["Not Recorded", "Recorded", "Not Required"],
    "receipt_status": ["No", "Yes", "Digital Only", "Not Required"],
}

# name, marketplace fee %, payment processing fee %, fixed processing fee
MARKETPLACE_DEFAULTS = [
    ("eBay", 0.1325, 0.0, 0.0),
    ("TCGplayer", 0.1025, 0.025, 0.30),
    ("Whatnot", 0.08, 0.029, 0.30),
    ("Facebook Marketplace", 0.0, 0.0, 0.0),
    ("Mercari", 0.10, 0.0, 0.0),
    ("Amazon", 0.15, 0.0, 0.0),
    ("Local Sale", 0.0, 0.0, 0.0),
    ("Discord", 0.0, 0.0, 0.0),
    ("Shopify", 0.029, 0.029, 0.30),
    ("Other", 0.0, 0.0, 0.0),
]

VENDOR_DEFAULTS = [
    ("Walmart", "Retailer", "https://www.walmart.com/"),
    ("Target", "Retailer", "https://www.target.com/"),
    ("Best Buy", "Retailer", "https://www.bestbuy.com/"),
    ("Amazon", "Marketplace", "https://www.amazon.com/"),
    ("TCGplayer", "Marketplace", "https://www.tcgplayer.com/"),
]


def seed_defaults_for_user(db: Session, user_id: str):
    for list_type, values in OPTION_DEFAULTS.items():
        for v in values:
            db.add(m.Option(user_id=user_id, list_type=list_type, value=v))

    for name, fee_pct, proc_pct, proc_fixed in MARKETPLACE_DEFAULTS:
        db.add(m.Marketplace(user_id=user_id, name=name, fee_pct=fee_pct,
                              processing_pct=proc_pct, processing_fixed=proc_fixed))

    for name, vtype, website in VENDOR_DEFAULTS:
        db.add(m.Vendor(user_id=user_id, name=name, vendor_type=vtype, website=website))

    db.commit()
