from datetime import date, datetime
from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..database import get_db
from ..auth import get_current_user
from .. import models as m
from .. import calculations as calc
from .. import reports

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def require_user(request: Request, db: Session):
    user = get_current_user(request, db)
    return user


def opts(db: Session, user_id: str, list_type: str) -> list[str]:
    rows = db.scalars(
        select(m.Option).where(m.Option.user_id == user_id, m.Option.list_type == list_type)
    ).all()
    return [r.value for r in rows]


def parse_date(s: str | None) -> date:
    if not s:
        return date.today()
    return datetime.strptime(s, "%Y-%m-%d").date()


# ------------------------------------------------------------------ Dashboard
@router.get("/")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    kpis = reports.dashboard_kpis(db, user.id)
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "kpis": kpis})


# ------------------------------------------------------------------ Vendors
@router.get("/vendors")
def vendors_list(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    vendors = db.scalars(select(m.Vendor).where(m.Vendor.user_id == user.id)).all()
    return templates.TemplateResponse("vendors.html", {
        "request": request, "user": user, "vendors": vendors, "edit_vendor": None,
        "vendor_types": opts(db, user.id, "vendor_type"),
    })


@router.get("/vendors/{vendor_id}/edit")
def vendors_edit_form(vendor_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    vendors = db.scalars(select(m.Vendor).where(m.Vendor.user_id == user.id)).all()
    edit_vendor = db.get(m.Vendor, vendor_id)
    return templates.TemplateResponse("vendors.html", {
        "request": request, "user": user, "vendors": vendors, "edit_vendor": edit_vendor,
        "vendor_types": opts(db, user.id, "vendor_type"),
    })


@router.post("/vendors")
def vendors_create(request: Request, db: Session = Depends(get_db),
                    name: str = Form(...), vendor_type: str = Form(""), website: str = Form(""),
                    tax_exempt: str = Form(""), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    db.add(m.Vendor(user_id=user.id, name=name, vendor_type=vendor_type, website=website,
                     tax_exempt=bool(tax_exempt), notes=notes))
    db.commit()
    return RedirectResponse("/vendors", status_code=303)


@router.post("/vendors/{vendor_id}/edit")
def vendors_update(vendor_id: int, request: Request, db: Session = Depends(get_db),
                    name: str = Form(...), vendor_type: str = Form(""), website: str = Form(""),
                    tax_exempt: str = Form(""), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    v = db.get(m.Vendor, vendor_id)
    if v and v.user_id == user.id:
        v.name, v.vendor_type, v.website = name, vendor_type, website
        v.tax_exempt, v.notes = bool(tax_exempt), notes
        db.commit()
    return RedirectResponse("/vendors", status_code=303)


@router.post("/vendors/{vendor_id}/delete")
def vendors_delete(vendor_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    v = db.get(m.Vendor, vendor_id)
    if v and v.user_id == user.id:
        db.delete(v)
        db.commit()
    return RedirectResponse("/vendors", status_code=303)


# ------------------------------------------------------------------ Purchases
@router.get("/purchases")
def purchases_list(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    purchases = db.scalars(select(m.Purchase).where(m.Purchase.user_id == user.id)).all()
    rows = [{
        "p": p,
        "allocated": calc.purchase_allocated_cost_basis(db, p),
        "item_count": calc.purchase_item_count(db, p),
        "remaining_diff": calc.purchase_remaining_difference(db, p),
    } for p in purchases]
    vendors = db.scalars(select(m.Vendor).where(m.Vendor.user_id == user.id)).all()
    return templates.TemplateResponse("purchases.html", {
        "request": request, "user": user, "rows": rows, "vendors": vendors, "edit_purchase": None,
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.get("/purchases/{purchase_id}/edit")
def purchases_edit_form(purchase_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    purchases = db.scalars(select(m.Purchase).where(m.Purchase.user_id == user.id)).all()
    rows = [{
        "p": p, "allocated": calc.purchase_allocated_cost_basis(db, p),
        "item_count": calc.purchase_item_count(db, p),
        "remaining_diff": calc.purchase_remaining_difference(db, p),
    } for p in purchases]
    vendors = db.scalars(select(m.Vendor).where(m.Vendor.user_id == user.id)).all()
    return templates.TemplateResponse("purchases.html", {
        "request": request, "user": user, "rows": rows, "vendors": vendors,
        "edit_purchase": db.get(m.Purchase, purchase_id),
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.post("/purchases")
def purchases_create(request: Request, db: Session = Depends(get_db),
                      vendor_id: int = Form(...), order_number: str = Form(""),
                      order_date: str = Form(...), payment_method: str = Form(""),
                      funding_source: str = Form(""), order_total: float = Form(0),
                      sales_tax: float = Form(0), shipping: float = Form(0), cashback: float = Form(0),
                      order_status: str = Form(""), receipt_available: str = Form(""),
                      quickbooks_recorded: str = Form("Not Recorded"), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    display_id = calc.next_display_id(db, user.id, m.Purchase, "PUR")
    db.add(m.Purchase(
        user_id=user.id, display_id=display_id, vendor_id=vendor_id, order_number=order_number,
        order_date=parse_date(order_date), payment_method=payment_method, funding_source=funding_source,
        order_total=order_total, sales_tax=sales_tax, shipping=shipping, cashback=cashback,
        order_status=order_status, receipt_available=receipt_available,
        quickbooks_recorded=quickbooks_recorded, notes=notes,
    ))
    db.commit()
    return RedirectResponse("/purchases", status_code=303)


@router.post("/purchases/{purchase_id}/edit")
def purchases_update(purchase_id: int, request: Request, db: Session = Depends(get_db),
                      vendor_id: int = Form(...), order_number: str = Form(""),
                      order_date: str = Form(...), payment_method: str = Form(""),
                      funding_source: str = Form(""), order_total: float = Form(0),
                      sales_tax: float = Form(0), shipping: float = Form(0), cashback: float = Form(0),
                      order_status: str = Form(""), receipt_available: str = Form(""),
                      quickbooks_recorded: str = Form("Not Recorded"), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    p = db.get(m.Purchase, purchase_id)
    if p and p.user_id == user.id:
        p.vendor_id, p.order_number, p.order_date = vendor_id, order_number, parse_date(order_date)
        p.payment_method, p.funding_source = payment_method, funding_source
        p.order_total, p.sales_tax, p.shipping, p.cashback = order_total, sales_tax, shipping, cashback
        p.order_status, p.receipt_available = order_status, receipt_available
        p.quickbooks_recorded, p.notes = quickbooks_recorded, notes
        db.commit()
    return RedirectResponse("/purchases", status_code=303)


@router.post("/purchases/{purchase_id}/delete")
def purchases_delete(purchase_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    p = db.get(m.Purchase, purchase_id)
    if p and p.user_id == user.id:
        db.delete(p)
        db.commit()
    return RedirectResponse("/purchases", status_code=303)


# ------------------------------------------------------------------ Inventory
@router.get("/inventory")
def inventory_list(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    items = db.scalars(select(m.InventoryItem).where(m.InventoryItem.user_id == user.id)).all()
    rows = [{
        "i": i,
        "total_cost_basis": calc.total_cost_basis(i),
        "qty_remaining": calc.quantity_remaining(db, i),
        "qty_sold": calc.quantity_sold(db, i),
        "days_held": calc.days_held_item(db, i),
        "profit": calc.item_profit(db, i),
        "roi": calc.item_roi(db, i),
    } for i in items]
    purchases = db.scalars(select(m.Purchase).where(m.Purchase.user_id == user.id)).all()
    return templates.TemplateResponse("inventory.html", {
        "request": request, "user": user, "rows": rows, "purchases": purchases, "edit_item": None,
        "categories": opts(db, user.id, "category"), "brands": opts(db, user.id, "brand"),
        "conditions": opts(db, user.id, "condition"),
        "storage_locations": opts(db, user.id, "storage_location"),
        "listing_statuses": opts(db, user.id, "listing_status"),
        "inventory_statuses": opts(db, user.id, "inventory_status"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.get("/inventory/{item_id}/edit")
def inventory_edit_form(item_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    items = db.scalars(select(m.InventoryItem).where(m.InventoryItem.user_id == user.id)).all()
    rows = [{
        "i": i, "total_cost_basis": calc.total_cost_basis(i),
        "qty_remaining": calc.quantity_remaining(db, i), "qty_sold": calc.quantity_sold(db, i),
        "days_held": calc.days_held_item(db, i), "profit": calc.item_profit(db, i),
        "roi": calc.item_roi(db, i),
    } for i in items]
    purchases = db.scalars(select(m.Purchase).where(m.Purchase.user_id == user.id)).all()
    return templates.TemplateResponse("inventory.html", {
        "request": request, "user": user, "rows": rows, "purchases": purchases,
        "edit_item": db.get(m.InventoryItem, item_id),
        "categories": opts(db, user.id, "category"), "brands": opts(db, user.id, "brand"),
        "conditions": opts(db, user.id, "condition"),
        "storage_locations": opts(db, user.id, "storage_location"),
        "listing_statuses": opts(db, user.id, "listing_status"),
        "inventory_statuses": opts(db, user.id, "inventory_status"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


def _inventory_form_kwargs(form_data) -> dict:
    return dict(
        purchase_id=form_data.get("purchase_id") or None,
        category=form_data.get("category", ""), brand=form_data.get("brand", ""),
        series_set=form_data.get("series_set", ""), product_name=form_data.get("product_name", ""),
        variant=form_data.get("variant", ""), condition=form_data.get("condition", ""),
        quantity=int(form_data.get("quantity") or 1),
        storage_location=form_data.get("storage_location", ""),
        purchase_price=float(form_data.get("purchase_price") or 0),
        allocated_sales_tax=float(form_data.get("allocated_sales_tax") or 0),
        allocated_shipping_in=float(form_data.get("allocated_shipping_in") or 0),
        allocated_cashback=float(form_data.get("allocated_cashback") or 0),
        current_market_value=float(form_data.get("current_market_value") or 0),
        listing_status=form_data.get("listing_status", "Not Listed"),
        inventory_status=form_data.get("inventory_status", "In Inventory"),
        quickbooks_recorded=form_data.get("quickbooks_recorded", "Not Recorded"),
        notes=form_data.get("notes", ""),
    )


@router.post("/inventory")
async def inventory_create(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    form = await request.form()
    display_id = calc.next_display_id(db, user.id, m.InventoryItem, "INV")
    db.add(m.InventoryItem(user_id=user.id, display_id=display_id, **_inventory_form_kwargs(form)))
    db.commit()
    return RedirectResponse("/inventory", status_code=303)


@router.post("/inventory/{item_id}/edit")
async def inventory_update(item_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    item = db.get(m.InventoryItem, item_id)
    if item and item.user_id == user.id:
        form = await request.form()
        for k, v in _inventory_form_kwargs(form).items():
            setattr(item, k, v)
        db.commit()
    return RedirectResponse("/inventory", status_code=303)


@router.post("/inventory/{item_id}/delete")
def inventory_delete(item_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    item = db.get(m.InventoryItem, item_id)
    if item and item.user_id == user.id:
        db.delete(item)
        db.commit()
    return RedirectResponse("/inventory", status_code=303)


# ------------------------------------------------------------------ Sales
@router.get("/sales")
def sales_list(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    sales = db.scalars(select(m.Sale).where(m.Sale.user_id == user.id)).all()
    rows = [{
        "s": s, "marketplace_fees": calc.sale_marketplace_fees(db, s),
        "processing_fees": calc.sale_processing_fees(db, s),
        "net_deposit": calc.sale_net_deposit(db, s), "cogs": calc.sale_cogs(db, s),
        "profit": calc.sale_profit(db, s), "roi": calc.sale_roi(db, s),
        "days_held": calc.sale_days_held(db, s),
    } for s in sales]
    items = db.scalars(select(m.InventoryItem).where(m.InventoryItem.user_id == user.id)).all()
    return templates.TemplateResponse("sales.html", {
        "request": request, "user": user, "rows": rows, "items": items, "edit_sale": None,
        "marketplaces": opts(db, user.id, "marketplace") or [x.name for x in db.scalars(
            select(m.Marketplace).where(m.Marketplace.user_id == user.id)).all()],
        "shipping_providers": opts(db, user.id, "shipping_provider"),
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.get("/sales/{sale_id}/edit")
def sales_edit_form(sale_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    sales = db.scalars(select(m.Sale).where(m.Sale.user_id == user.id)).all()
    rows = [{
        "s": s, "marketplace_fees": calc.sale_marketplace_fees(db, s),
        "processing_fees": calc.sale_processing_fees(db, s),
        "net_deposit": calc.sale_net_deposit(db, s), "cogs": calc.sale_cogs(db, s),
        "profit": calc.sale_profit(db, s), "roi": calc.sale_roi(db, s),
        "days_held": calc.sale_days_held(db, s),
    } for s in sales]
    items = db.scalars(select(m.InventoryItem).where(m.InventoryItem.user_id == user.id)).all()
    mkts = [x.name for x in db.scalars(select(m.Marketplace).where(m.Marketplace.user_id == user.id)).all()]
    return templates.TemplateResponse("sales.html", {
        "request": request, "user": user, "rows": rows, "items": items,
        "edit_sale": db.get(m.Sale, sale_id), "marketplaces": mkts,
        "shipping_providers": opts(db, user.id, "shipping_provider"),
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.post("/sales")
def sales_create(request: Request, db: Session = Depends(get_db),
                  inventory_id: int = Form(...), sale_date: str = Form(...),
                  marketplace: str = Form(""), buyer: str = Form(""), order_number: str = Form(""),
                  tracking_number: str = Form(""), shipping_provider: str = Form(""),
                  payment_method: str = Form(""), quantity_sold: int = Form(1),
                  sale_price: float = Form(0), sales_tax_collected: float = Form(0),
                  shipping_cost: float = Form(0), quickbooks_recorded: str = Form("Not Recorded"),
                  notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    display_id = calc.next_display_id(db, user.id, m.Sale, "SAL")
    db.add(m.Sale(
        user_id=user.id, display_id=display_id, inventory_id=inventory_id, sale_date=parse_date(sale_date),
        marketplace=marketplace, buyer=buyer, order_number=order_number, tracking_number=tracking_number,
        shipping_provider=shipping_provider, payment_method=payment_method, quantity_sold=quantity_sold,
        sale_price=sale_price, sales_tax_collected=sales_tax_collected, shipping_cost=shipping_cost,
        quickbooks_recorded=quickbooks_recorded, notes=notes,
    ))
    db.commit()
    return RedirectResponse("/sales", status_code=303)


@router.post("/sales/{sale_id}/edit")
def sales_update(sale_id: int, request: Request, db: Session = Depends(get_db),
                  inventory_id: int = Form(...), sale_date: str = Form(...),
                  marketplace: str = Form(""), buyer: str = Form(""), order_number: str = Form(""),
                  tracking_number: str = Form(""), shipping_provider: str = Form(""),
                  payment_method: str = Form(""), quantity_sold: int = Form(1),
                  sale_price: float = Form(0), sales_tax_collected: float = Form(0),
                  shipping_cost: float = Form(0), quickbooks_recorded: str = Form("Not Recorded"),
                  notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    s = db.get(m.Sale, sale_id)
    if s and s.user_id == user.id:
        s.inventory_id, s.sale_date = inventory_id, parse_date(sale_date)
        s.marketplace, s.buyer, s.order_number = marketplace, buyer, order_number
        s.tracking_number, s.shipping_provider, s.payment_method = tracking_number, shipping_provider, payment_method
        s.quantity_sold, s.sale_price = quantity_sold, sale_price
        s.sales_tax_collected, s.shipping_cost = sales_tax_collected, shipping_cost
        s.quickbooks_recorded, s.notes = quickbooks_recorded, notes
        db.commit()
    return RedirectResponse("/sales", status_code=303)


@router.post("/sales/{sale_id}/delete")
def sales_delete(sale_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    s = db.get(m.Sale, sale_id)
    if s and s.user_id == user.id:
        db.delete(s)
        db.commit()
    return RedirectResponse("/sales", status_code=303)


# ------------------------------------------------------------------ Expenses
@router.get("/expenses")
def expenses_list(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    expenses = db.scalars(select(m.Expense).where(m.Expense.user_id == user.id)).all()
    return templates.TemplateResponse("expenses.html", {
        "request": request, "user": user, "expenses": expenses, "edit_expense": None,
        "expense_categories": opts(db, user.id, "expense_category"),
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.get("/expenses/{expense_id}/edit")
def expenses_edit_form(expense_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    expenses = db.scalars(select(m.Expense).where(m.Expense.user_id == user.id)).all()
    return templates.TemplateResponse("expenses.html", {
        "request": request, "user": user, "expenses": expenses,
        "edit_expense": db.get(m.Expense, expense_id),
        "expense_categories": opts(db, user.id, "expense_category"),
        "payment_methods": opts(db, user.id, "payment_method"),
        "qb_statuses": opts(db, user.id, "quickbooks_status"),
    })


@router.post("/expenses")
def expenses_create(request: Request, db: Session = Depends(get_db),
                     date_: str = Form(..., alias="date"), vendor: str = Form(""),
                     expense_category: str = Form(""), payment_method: str = Form(""),
                     amount: float = Form(0), receipt_attached: str = Form("No"),
                     quickbooks_recorded: str = Form("Not Recorded"), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    display_id = calc.next_display_id(db, user.id, m.Expense, "EXP")
    db.add(m.Expense(
        user_id=user.id, display_id=display_id, date=parse_date(date_), vendor=vendor,
        expense_category=expense_category, payment_method=payment_method, amount=amount,
        receipt_attached=receipt_attached, quickbooks_recorded=quickbooks_recorded, notes=notes,
    ))
    db.commit()
    return RedirectResponse("/expenses", status_code=303)


@router.post("/expenses/{expense_id}/edit")
def expenses_update(expense_id: int, request: Request, db: Session = Depends(get_db),
                     date_: str = Form(..., alias="date"), vendor: str = Form(""),
                     expense_category: str = Form(""), payment_method: str = Form(""),
                     amount: float = Form(0), receipt_attached: str = Form("No"),
                     quickbooks_recorded: str = Form("Not Recorded"), notes: str = Form("")):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    e = db.get(m.Expense, expense_id)
    if e and e.user_id == user.id:
        e.date, e.vendor, e.expense_category = parse_date(date_), vendor, expense_category
        e.payment_method, e.amount = payment_method, amount
        e.receipt_attached, e.quickbooks_recorded, e.notes = receipt_attached, quickbooks_recorded, notes
        db.commit()
    return RedirectResponse("/expenses", status_code=303)


@router.post("/expenses/{expense_id}/delete")
def expenses_delete(expense_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    e = db.get(m.Expense, expense_id)
    if e and e.user_id == user.id:
        db.delete(e)
        db.commit()
    return RedirectResponse("/expenses", status_code=303)


# ------------------------------------------------------------------ Settings (Reference Lists)
LIST_TYPE_LABELS = {
    "category": "Categories", "brand": "Brands / IP", "condition": "Conditions",
    "vendor_type": "Vendor Types", "payment_method": "Payment Methods",
    "storage_location": "Storage Locations", "expense_category": "Expense Categories",
    "shipping_provider": "Shipping Providers", "inventory_status": "Inventory Status",
    "listing_status": "Listing Status", "quickbooks_status": "QuickBooks Status",
    "receipt_status": "Receipt Status",
}


@router.get("/settings")
def settings_page(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    lists = {}
    for list_type, label in LIST_TYPE_LABELS.items():
        rows = db.scalars(
            select(m.Option).where(m.Option.user_id == user.id, m.Option.list_type == list_type)
        ).all()
        lists[list_type] = {"label": label, "rows": rows}
    marketplaces = db.scalars(select(m.Marketplace).where(m.Marketplace.user_id == user.id)).all()
    return templates.TemplateResponse("settings.html", {
        "request": request, "user": user, "lists": lists, "marketplaces": marketplaces,
    })


@router.post("/settings/options/add")
def settings_option_add(request: Request, db: Session = Depends(get_db),
                         list_type: str = Form(...), value: str = Form(...)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    if value.strip():
        db.add(m.Option(user_id=user.id, list_type=list_type, value=value.strip()))
        db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/settings/options/{option_id}/delete")
def settings_option_delete(option_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    o = db.get(m.Option, option_id)
    if o and o.user_id == user.id:
        db.delete(o)
        db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/settings/marketplaces/add")
def settings_marketplace_add(request: Request, db: Session = Depends(get_db),
                              name: str = Form(...), fee_pct: float = Form(0),
                              processing_pct: float = Form(0), processing_fixed: float = Form(0)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    db.add(m.Marketplace(user_id=user.id, name=name, fee_pct=fee_pct / 100,
                          processing_pct=processing_pct / 100, processing_fixed=processing_fixed))
    db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/settings/marketplaces/{mk_id}/delete")
def settings_marketplace_delete(mk_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    mk = db.get(m.Marketplace, mk_id)
    if mk and mk.user_id == user.id:
        db.delete(mk)
        db.commit()
    return RedirectResponse("/settings", status_code=303)


# ------------------------------------------------------------------ Deal Calculator
@router.get("/deal-calculator")
def deal_calculator(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    marketplaces = db.scalars(select(m.Marketplace).where(m.Marketplace.user_id == user.id)).all()
    mk_json = [{"name": mk.name, "fee_pct": mk.fee_pct, "processing_pct": mk.processing_pct,
                "processing_fixed": mk.processing_fixed} for mk in marketplaces]
    return templates.TemplateResponse("deal_calculator.html", {
        "request": request, "user": user, "marketplaces": mk_json,
    })


# ------------------------------------------------------------------ Analytics
@router.get("/analytics")
def analytics_page(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("analytics.html", {
        "request": request, "user": user,
        "monthly": reports.monthly_trend(db, user.id),
        "categories": reports.category_performance(db, user.id),
        "vendors": reports.vendor_performance(db, user.id),
        "marketplaces": reports.marketplace_performance(db, user.id),
        "aging": reports.inventory_aging(db, user.id),
    })
