"""
Every number in the old spreadsheet that was a formula (Total Cost Basis,
Quantity Remaining, Days Held, Profit, ROI, etc.) is recomputed here from the
raw stored fields, the same way the workbook derived them from its tables.
Nothing derived is stored in the database -- it's always calculated fresh,
so there is no risk of stale numbers.
"""
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import select
from . import models as m

TODAY = date.today


def total_cost_basis(item: m.InventoryItem) -> float:
    return round(
        item.purchase_price + item.allocated_sales_tax + item.allocated_shipping_in
        - item.allocated_cashback,
        2,
    )


def quantity_sold(db: Session, item: m.InventoryItem) -> int:
    sales = db.scalars(
        select(m.Sale).where(m.Sale.inventory_id == item.id)
    ).all()
    return sum(s.quantity_sold for s in sales)


def quantity_remaining(db: Session, item: m.InventoryItem) -> int:
    return max(0, item.quantity - quantity_sold(db, item))


def purchase_date_of(item: m.InventoryItem) -> date | None:
    return item.purchase.order_date if item.purchase else None


def days_held_item(db: Session, item: m.InventoryItem) -> int | None:
    pdate = purchase_date_of(item)
    if pdate is None:
        return None
    qty_rem = quantity_remaining(db, item)
    if qty_rem == 0:
        sales = db.scalars(select(m.Sale).where(m.Sale.inventory_id == item.id)).all()
        if not sales:
            return (TODAY() - pdate).days
        last_sale = max(s.sale_date for s in sales)
        return (last_sale - pdate).days
    return (TODAY() - pdate).days


def marketplace_lookup(db: Session, user_id: str, name: str) -> m.Marketplace | None:
    return db.scalar(
        select(m.Marketplace).where(m.Marketplace.user_id == user_id, m.Marketplace.name == name)
    )


def sale_marketplace_fees(db: Session, sale: m.Sale) -> float:
    mk = marketplace_lookup(db, sale.user_id, sale.marketplace)
    if not mk:
        return 0.0
    return round(sale.sale_price * mk.fee_pct, 2)


def sale_processing_fees(db: Session, sale: m.Sale) -> float:
    mk = marketplace_lookup(db, sale.user_id, sale.marketplace)
    if not mk:
        return 0.0
    return round(sale.sale_price * mk.processing_pct + mk.processing_fixed, 2)


def sale_net_deposit(db: Session, sale: m.Sale) -> float:
    return round(
        sale.sale_price + sale.sales_tax_collected
        - sale_marketplace_fees(db, sale) - sale_processing_fees(db, sale) - sale.shipping_cost,
        2,
    )


def sale_cogs(db: Session, sale: m.Sale) -> float:
    item = db.get(m.InventoryItem, sale.inventory_id)
    if not item or not item.quantity:
        return 0.0
    return round(total_cost_basis(item) / item.quantity * sale.quantity_sold, 2)


def sale_profit(db: Session, sale: m.Sale) -> float:
    return round(sale_net_deposit(db, sale) - sale_cogs(db, sale), 2)


def sale_roi(db: Session, sale: m.Sale) -> float | None:
    cogs = sale_cogs(db, sale)
    return round(sale_profit(db, sale) / cogs, 4) if cogs else None


def sale_days_held(db: Session, sale: m.Sale) -> int | None:
    item = db.get(m.InventoryItem, sale.inventory_id)
    pdate = purchase_date_of(item) if item else None
    if pdate is None:
        return None
    return (sale.sale_date - pdate).days


def item_profit(db: Session, item: m.InventoryItem) -> float:
    sales = db.scalars(select(m.Sale).where(m.Sale.inventory_id == item.id)).all()
    return round(sum(sale_profit(db, s) for s in sales), 2)


def item_roi(db: Session, item: m.InventoryItem) -> float | None:
    sales = db.scalars(select(m.Sale).where(m.Sale.inventory_id == item.id)).all()
    cogs_total = sum(sale_cogs(db, s) for s in sales)
    if not cogs_total:
        return None
    return round(sum(sale_profit(db, s) for s in sales) / cogs_total, 4)


def purchase_allocated_cost_basis(db: Session, purchase: m.Purchase) -> float:
    items = db.scalars(
        select(m.InventoryItem).where(m.InventoryItem.purchase_id == purchase.id)
    ).all()
    return round(sum(total_cost_basis(i) for i in items), 2)


def purchase_item_count(db: Session, purchase: m.Purchase) -> int:
    items = db.scalars(
        select(m.InventoryItem).where(m.InventoryItem.purchase_id == purchase.id)
    ).all()
    return len(items)


def purchase_remaining_difference(db: Session, purchase: m.Purchase) -> float:
    return round(purchase.order_total - purchase_allocated_cost_basis(db, purchase), 2)


def next_display_id(db: Session, user_id: str, model, prefix: str) -> str:
    """Mirrors the sheet's ROW()-based auto-numbering: next sequential ID
    for this user, per entity type."""
    count = len(db.scalars(select(model).where(model.user_id == user_id)).all())
    return f"{prefix}-{count + 1:06d}"
