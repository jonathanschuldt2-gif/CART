import os
from dotenv import load_dotenv

load_dotenv()

SESSION_SECRET = os.getenv("SESSION_SECRET", "dev-only-change-me")

# Set to "false" to close public sign-up once everyone who needs an
# account has one (existing users can still log in as normal).
ALLOW_REGISTRATION = os.getenv("ALLOW_REGISTRATION", "true").strip().lower() != "false"

# If set, use this Postgres database (as provided by Render or any other
# host) instead of a local SQLite file. Leave unset for local development.
DATABASE_URL = os.getenv("DATABASE_URL", "").strip() or None

# Render sets RENDER=true automatically on every deployed service. This lets
# the app tell "running on my laptop" apart from "running in the cloud"
# without any manual flag — but ENVIRONMENT=production also works on any
# other host that doesn't set RENDER.
IS_PRODUCTION = bool(os.getenv("RENDER")) or os.getenv("ENVIRONMENT", "").strip().lower() == "production"

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
