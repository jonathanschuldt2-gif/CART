from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from . import config as cfg
from .database import Base, engine
from . import models  # noqa: F401  (registers tables on Base.metadata)
from .auth import router as auth_router
from .routers.pages import router as pages_router

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Collectibles Reseller Operating System")

# Cookies only travel over HTTPS once we're actually deployed (Render
# terminates TLS in front of the app). Locally, https_only would block
# login over plain http://127.0.0.1, so it's only turned on in production.
app.add_middleware(
    SessionMiddleware,
    secret_key=cfg.SESSION_SECRET,
    same_site="lax",
    https_only=cfg.IS_PRODUCTION,
)

app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(auth_router)
app.include_router(pages_router)


@app.get("/healthz")
def healthz():
    """Simple liveness check Render (or any host) can poll."""
    return {"status": "ok"}
